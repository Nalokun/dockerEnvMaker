
public class Student {

    private String name;
    private int id;
    private int mark1;
    private int mark2;
    private int mark3;

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public Student() {
    }

    public Student(int id, String name, int mark1, int mark2, int mark3) {
        this.id = id;
        this.mark1 = mark1;
        this.mark2 = mark2;
        this.mark3 = mark3;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMark1() {
        return mark1;
    }

    public void setMark1(int mark1) {
        this.mark1 = mark1;
    }

    public int getMark2() {
        return mark2;
    }

    public void setMark2(int mark2) {
        this.mark2 = mark2;
    }

    public int getMark3() {
        return mark3;
    }

    public void setMark3(int mark3) {
        this.mark3 = mark3;
    }

    public int calculateTotal() {
        return getMark1() + getMark2() + getMark3();
    }

    public int calculateAverage() {
        return calculateTotal() / 3;
    }

    public int findHighestMark() {
        // 2 2 1
        if (mark1 >= mark2 && mark1 > mark3) {
            return mark1;
        } else if (mark1 <= mark2 && mark2 > mark3) {
            return mark2;
        }
        return mark3;
    }

    public int findLowestMark() {
        // 2 2 2
        // 2 1 2
        // 1 2 2
        // 3 2 1
        if (mark1 <= mark2 && mark1 <= mark3) {
            return mark1;
        } else if (mark2 <= mark1 && mark2 <= mark3) {
            return mark2;
        }
        return mark3;
    }

    public void displayInfo() {
        System.out.println("name is : " + getName() + ", id is : " + getId() + " and the marks is : " + getMark1() + " " + getMark2() + " " + getMark3());
    }
}

public class Main {
    public static void main(String[] args) {
        int id=1;
        Student s1=new Student();
        Student s2=new Student(id,"ahmad");
        Student s3=new Student(id,"ahmad",50,60,70);
        s1.displayInfo();
        s2.displayInfo();
        s3.displayInfo();
    }
}