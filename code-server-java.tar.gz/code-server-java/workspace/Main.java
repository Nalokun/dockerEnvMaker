

public class Main {
    public static void main(String[] args) {
        int id=1;
        Student s1=new Student();
        Student s2=new Student(id,"ahmad");
        Student s3=new Student(id,"ahmad",50,60,70);
        s1.displayInfo();
        s2.displayInfo();
        s3.displayInfo();
    }
}